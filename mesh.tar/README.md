# Mesh
MESH: Multi-host Execution &amp; Setup for High-performance JAX

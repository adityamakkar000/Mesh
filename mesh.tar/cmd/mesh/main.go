package main

import (
	"log"

	"github.com/adityamakkar000/Mesh/internal/build"
	cli "github.com/adityamakkar000/Mesh/internal/parse"
)

func main() {
	_, err := cli.Clusters()
	if err != nil {
		log.Fatal(err)
	}


	build.BuildTar()


}

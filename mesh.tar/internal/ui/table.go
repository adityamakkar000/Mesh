package ui

// TODO(william): function for printing a table given "headers" []string (columns), and a matrix [][]string
